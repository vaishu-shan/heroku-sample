
import React from 'react'
import "./home.css"
import Mainpannel from '../../component/Mainpannel/main'

export default function HomePage() {
  return (
   <>
   
  
   <Mainpannel/>
   </>
  )
}
